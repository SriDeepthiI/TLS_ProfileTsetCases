import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class SearchTLSProfile {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        TLS_Profile tp = new TLS_Profile();
        try {
            tp.signIN(driver);
            tp.configuration(driver);
            boolean add_Multiple = tp.add_Multiple_TLS_Profile(driver, "name", 2);
            assert add_Multiple;
            boolean search = tp.searchTLS_Profile(driver, "name1");
            assert search;
        } catch (InterruptedException e) {
            System.out.println(e);
        } finally {
            tp.cleanUp(driver);
            tp.logOut(driver);
        }
    }
}

