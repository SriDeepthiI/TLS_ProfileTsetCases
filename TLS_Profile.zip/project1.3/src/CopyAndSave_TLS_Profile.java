import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class CopyAndSave_TLS_Profile {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        TLS_Profile tp = new TLS_Profile();
        try {
            tp.signIN(driver);
            tp.configuration(driver);
            boolean add = tp.add_TLS_Profile(driver, "name1", "entity1", "cer1", "list1");
            assert add;
            boolean copy = tp.copyAndSave_TLSProfile(driver, "name1", "name2");
            assert copy;
        }
        catch (InterruptedException e) {
            System.out.println(e);
        } finally {
            tp.cleanUp(driver);
            tp.logOut(driver);
        }
    }
}


